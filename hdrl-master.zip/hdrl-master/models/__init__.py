# -*- coding: utf-8 -*-
from .models import Model
