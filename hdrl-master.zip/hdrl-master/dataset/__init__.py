
from .amazon import AmazonData
